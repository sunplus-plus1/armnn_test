//
// Copyright © 2019 Arm Ltd. All rights reserved.
// SPDX-License-Identifier: MIT
//

// This file is depricated and will be removed soon.
// Please use the new header in armnn/backends instead.
// This will use the new armnn/backends header.
#include <armnn/backends/OptimizationViews.hpp>
