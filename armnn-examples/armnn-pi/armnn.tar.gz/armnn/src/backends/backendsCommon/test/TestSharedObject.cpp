//
// Copyright © 2017 Arm Ltd. All rights reserved.
// SPDX-License-Identifier: MIT
//

#include "TestSharedObject.hpp"

int TestFunction1(int i)
{
    return i;
}

int TestFunction2(int i)
{
    return i;
}

int TestFunction3(int i)
{
    return i;
}
