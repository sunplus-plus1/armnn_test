//
// Copyright © 2017 Arm Ltd. All rights reserved.
// SPDX-License-Identifier: MIT
//
#pragma once

namespace
{

template<typename WorkloadFactoryType> struct WorkloadFactoryHelper {};

} // anonymous namespace