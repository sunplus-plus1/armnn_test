#ifndef BOOST_PENDING_INTEGER_LOG2_HPP
#define BOOST_PENDING_INTEGER_LOG2_HPP

// The header file at this path is deprecated;
// use boost/integer/integer_log2.hpp instead.

#include <boost/integer/integer_log2.hpp>

#endif
